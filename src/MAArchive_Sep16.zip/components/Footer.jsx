import AgfiLogo from "../ui/AgfiLogo";


export default function Footer() {
    return(
        <>
        
        <p>powered by</p>

        <AgfiLogo />
        
        </>
    )
}