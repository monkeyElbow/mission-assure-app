// src/pages/TripDetail.jsx
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../data/api'
import { daysInclusive, computeTripTotalCents } from '../core/pricing'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { fadeSlide } from '../ui/motion'
import { selectRate } from '../core/rates';


export default function TripDetail(){
  
  const { id } = useParams()

  const nav = useNavigate();

  const [trip, setTrip] = useState(null)
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [err, setErr] = useState('')

  // add-member form state
  const [newMember, setNewMember] = useState({ firstName:'', lastName:'', email:'' })
  const [adding, setAdding] = useState(false)

  // edit-trip optimistic state
  const [savingTrip, setSavingTrip] = useState(false)

  useEffect(() => {
    let alive = true
    ;(async () => {
      try{
        const { trip, members } = await api.getTrip(id)
        if(!alive) return
        setTrip(trip); setMembers(members); setLoading(false)
      }catch(ex){
        if(!alive) return
        setErr(ex.message || 'Failed to load trip'); setLoading(false)
      }
    })()
    return () => { alive = false }
  }, [id])

  async function refreshMembers(){
    const { members } = await api.getTrip(id)
    setMembers(members)
  }

  async function handleAddMember(e){
    e.preventDefault()
    setErr('')
    if(!newMember.firstName || !newMember.lastName || !newMember.email){
      setErr('First name, last name, and email are required.')
      return
    }
    setAdding(true)
    try{
      await api.addMembers(trip.id, [newMember])
      await refreshMembers()
      setNewMember({ firstName:'', lastName:'', email:'' })
    }catch(ex){
      setErr(ex.message || 'Failed to add member')
    }finally{
      setAdding(false)
    }
  }

  async function handleMemberField(m, field, value){
    setMembers(ms => ms.map(x => x.id===m.id ? { ...x, [field]: value } : x))
    try{
      await api.updateMember(m.id, { [field]: value })
    }catch(ex){
      setErr(ex.message || 'Failed to update member')
      // optional: reload to revert on error
      await refreshMembers()
    }
  }

  async function handleRemoveMember(m){
    if(!confirm(`Remove ${m.firstName} ${m.lastName}?`)) return
    try{
      await api.removeMember(m.id)
      setMembers(ms => ms.filter(x => x.id !== m.id))
    }catch(ex){
      setErr(ex.message || 'Failed to remove member')
    }
  }

  async function saveTrip(){
    setSavingTrip(true); setErr('')
    try{
      const saved = await api.updateTrip(trip.id, {
        title: trip.title,
        startDate: trip.startDate,
        endDate: trip.endDate,
        region: trip.region
      })
      setTrip(saved)
    }catch(ex){
      setErr(ex.message || 'Failed to save trip')
    }finally{
      setSavingTrip(false)
    }
  }

  if (loading) return <div className="container my-3"><p className="text-muted">Loading…</p></div>
  if (!trip) return <div className="container my-3"><p className="text-danger">Trip not found.</p></div>

  const days = daysInclusive(trip.startDate, trip.endDate)
  const total = computeTripTotalCents(trip, members) / 100

  // Claims gate: allowed only if paid, within grace window
const gracePeriodDays = 90; // change if Legal wants different
const endPlusGrace = new Date(trip.endDate);
endPlusGrace.setDate(endPlusGrace.getDate() + gracePeriodDays);

const claimsOpen =
  trip.paymentStatus === 'PAID' &&
  new Date() <= endPlusGrace;


  function computeTotals(trip, members){
    if(!trip) return { days:0, headcount:0, rate:0, subtotal:0 };
    const start = new Date(trip.startDate);
    const end   = new Date(trip.endDate);
    const ms = Math.max(0, end - start);
    const days = Math.max(1, Math.ceil(ms / (1000*60*60*24))); // charge at least 1 day
    const headcount = members?.length ?? 0;
    const rate = trip.rateCents ?? 0;
    const subtotal = days * headcount * rate;
    return { days, headcount, rate, subtotal };
  }
  

  return (
    <div className="container my-3" style={{maxWidth: 1100}}>
      {err && <div className="alert alert-danger py-2">{err}</div>}

      <div className="d-flex align-items-center justify-content-between mb-1">
  <h1 className="h3 mb-0">
    {trip.title || 'Untitled Trip'}
    {trip.shortId && (
      <span className="text-muted ms-2 small">#{trip.shortId}</span>
    )}
  </h1>

  <div className="d-flex gap-2">
    <span className="badge text-bg-light">{trip.region}</span>
    <span className={`badge ${trip.paymentStatus==='PAID'
      ? 'text-bg-success'
      : 'text-bg-warning'}`}>
      {trip.paymentStatus}
    </span>
    {trip.status==='ARCHIVED' && (
      <span className="badge text-bg-secondary">ARCHIVED</span>
    )}
  </div>
</div>

      <div className="small text-muted mb-3">
        {trip.startDate} → {trip.endDate} • {days} days • {members.length} people • ${(trip.rateCents/100).toFixed(2)}/day
      </div>

      <div className="row g-3">
        {/* LEFT: Members */}
        <div className="col-lg-7">
          {/* Add member */}
          <div className="card p-3 mb-3">
            <h2 className="h6 mb-2">Add person</h2>
            <form className="row g-2" onSubmit={handleAddMember}>
              <div className="col-md-4">
                <input
                  className="form-control"
                  placeholder="First name"
                  value={newMember.firstName}
                  onChange={e=>setNewMember(s=>({...s, firstName:e.target.value}))}
                />
              </div>
              <div className="col-md-4">
                <input
                  className="form-control"
                  placeholder="Last name"
                  value={newMember.lastName}
                  onChange={e=>setNewMember(s=>({...s, lastName:e.target.value}))}
                />
              </div>
              <div className="col-md-4">
                <input
                  type="email"
                  className="form-control"
                  placeholder="Email"
                  value={newMember.email}
                  onChange={e=>setNewMember(s=>({...s, email:e.target.value}))}
                />
              </div>
              <div className="col-12">
                <button className="btn btn-primary btn-sm" disabled={adding}>
                  {adding ? 'Adding…' : 'Add'}
                </button>
              </div>
            </form>
          </div>

          {/* Members list */}
          <div className="card p-3">
            <h2 className="h5 mb-2">People</h2>
            {members.length === 0 ? (
              <p className="text-muted mb-0">No members yet.</p>
            ) : (
              <ul className="list-group list-group-flush">
  <AnimatePresence>
    {members.map(m => (
      <motion.li
        key={m.id}
        {...fadeSlide}
        className="list-group-item"
      >
        <div className="d-flex flex-wrap align-items-center gap-2">
          <input
            className="form-control form-control-sm"
            style={{maxWidth:160}}
            value={m.firstName || ''}
            onChange={e=>handleMemberField(m,'firstName',e.target.value)}
          />
          <input
            className="form-control form-control-sm"
            style={{maxWidth:160}}
            value={m.lastName || ''}
            onChange={e=>handleMemberField(m,'lastName',e.target.value)}
          />
          <input
            type="email"
            className="form-control form-control-sm"
            style={{minWidth:220}}
            value={m.email || ''}
            onChange={e=>handleMemberField(m,'email',e.target.value)}
          />
          <span className="badge text-bg-secondary ms-auto">{m.status || 'IN_PROGRESS'}</span>
          <button
            className="btn btn-outline-danger btn-sm"
            onClick={()=>handleRemoveMember(m)}
          >
            Remove
          </button>
        </div>
      </motion.li>
    ))}
  </AnimatePresence>
</ul>

            )}
          </div>
        </div>

        {/* RIGHT: Payment + Edit Trip */}
        <div className="col-lg-5">
        <div className="card p-3 mb-3">
  <div className="d-flex justify-content-between align-items-center mb-2">
    <h2 className="h5 mb-0">Payment Summary</h2>
    <span className={`badge ${trip.paymentStatus === 'PAID' ? 'text-bg-success' : 'text-bg-secondary'}`}>
      {trip.paymentStatus === 'PAID' ? 'PAID' : 'UNPAID'}
    </span>
  </div>

  <div className="d-flex justify-content-between">
    <span>Subtotal</span>
    <strong>${total.toFixed(2)}</strong>
  </div>

  {/* Demo-only: mark paid */}
  {trip.paymentStatus !== 'PAID' ? (
    <button
      className="btn btn-primary mt-3"
      onClick={async ()=>{
        const saved = await api.updateTrip(trip.id, { paymentStatus: 'PAID' });
        setTrip(saved);
      }}
    >
      Mark as Paid (demo)
    </button>
  ) : (
    <button className="btn btn-primary mt-3" disabled>
      Paid via Stripe (coming)
    </button>)}

    <button
  className="btn btn-outline-secondary mb-3 mt-3"
  disabled={!claimsOpen}
  title={
    trip.paymentStatus !== 'PAID'
      ? 'Coverage not active until payment.'
      : `Claims window ends ${endPlusGrace.toISOString().slice(0,10)}`
  }
  onClick={()=>{
    nav('/claims', { state: { tripId: trip.id, tripTitle: trip.title } })
  }}
>
  Report a claim
</button>

          </div>

          <div className="card p-3">
            <h2 className="h5 mb-2">Edit Trip</h2>
            <div className="row g-2">
              <div className="col-12">
                <label className="form-label">Title</label>
                <input
                  className="form-control"
                  value={trip.title || ''}
                  onChange={e=>setTrip(t=>({...t, title:e.target.value}))}
                />
              </div>
              <div className="col-md-6">
                <label className="form-label">Start</label>
                <input
                  type="date"
                  className="form-control"
                  value={trip.startDate || ''}
                  onChange={e=>setTrip(t=>({...t, startDate:e.target.value}))}
                />
              </div>
              <div className="col-md-6">
                <label className="form-label">End</label>
                <input
                  type="date"
                  className="form-control"
                  value={trip.endDate || ''}
                  onChange={e=>setTrip(t=>({...t, endDate:e.target.value}))}
                />
              </div>
              <div className="col-12">
                <label className="form-label me-3">Region</label>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    id="reg-dom"
                    name="region"
                    checked={trip.region==='DOMESTIC'}
                    onChange={()=>setTrip(t=>({...t, region:'DOMESTIC'}))}
                  />
                  <label className="form-check-label" htmlFor="reg-dom">Domestic</label>
                </div>
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="radio"
                    id="reg-for"
                    name="region"
                    checked={trip.region==='INTERNATIONAL'}
                    onChange={()=>setTrip(t=>({...t, region:'INTERNATIONAL'}))}
                  />
                  <label className="form-check-label" htmlFor="reg-for">International</label>
                </div>
              </div>
              <div className="col-12 d-flex justify-content-between">
    <button className="btn btn-primary" onClick={saveTrip} disabled={savingTrip}>
      {savingTrip ? 'Saving…' : 'Save Changes'}
    </button>
    <button
      className="btn btn-outline-secondary"
      onClick={async ()=>{
        const saved = await api.updateTrip(trip.id, { status: 'ARCHIVED' })
        setTrip(saved)
      }}
    >
      Archive Trip
    </button>

  {/* <button
    className="btn btn-outline-danger"
    onClick={async ()=>{
      if (!confirm(`Delete this trip "${trip.title}" (${trip.shortId||trip.id})? This removes its members and claims.`)) return;
      await api.deleteTrip(trip.id);
      nav('/'); 
    }}
  >
    Delete Trip
  </button> */}
</div>

            </div>
          </div>

        </div>
      </div>
    </div>
  )
}
