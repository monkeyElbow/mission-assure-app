// src/pages/Dashboard.jsx
import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { api, seedDemoIfEmpty } from '../data/api'
import { daysInclusive } from '../core/pricing'
import { motion, AnimatePresence } from 'framer-motion'
import { fadeSlide } from '../ui/motion'


function TripCard({ t, memberCount }){
  const days = daysInclusive(t.startDate, t.endDate);
  const perDay = (t.rateCents/100).toFixed(2);
  return (
    <div className="card p-3 h-100">
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <h2 className="h5 mb-1">
            {t.title}
            {t.shortId && (
              <span className="text-muted ms-2 small">#{t.shortId}</span>
            )}
          </h2>
          <div className="small text-muted">
            {t.startDate} → {t.endDate} • {days} days • {memberCount} people • ${perDay}/day
          </div>
        </div>
        <div className="d-flex gap-2">
          <span className="badge text-bg-light">{t.region}</span>
          <span className={`badge ${t.paymentStatus==='PAID' ? 'text-bg-success' : 'text-bg-warning'}`}>
            {t.paymentStatus}
          </span>
          {t.status==='ARCHIVED' && (
            <span className="badge text-bg-secondary">ARCHIVED</span>
          )}
        </div>
      </div>
      <div className="d-flex gap-2 mt-3">
        <Link to={`/trips/${t.id}`} className="btn btn-sm btn-primary">Open</Link>
      </div>
    </div>
  )
  
}

export default function Dashboard(){
  const [trips, setTrips] = useState([])
  const [membersByTrip, setMembersByTrip] = useState({})
  const [filter, setFilter] = useState('ACTIVE') // ACTIVE | ARCHIVED | ALL

  useEffect(() => {
    seedDemoIfEmpty();
    (async () => {
      const ts = await api.listTrips();
      setTrips(ts);
      const counts = {};
      await Promise.all(ts.map(async t => {
        const { members } = await api.getTrip(t.id);
        counts[t.id] = members.length;
      }));
      setMembersByTrip(counts);
    })();
  }, []);

  // counts for pills
  const counts = useMemo(() => {
    const c = { ACTIVE:0, ARCHIVED:0, ALL: trips.length };
    trips.forEach(t => { c[t.status === 'ARCHIVED' ? 'ARCHIVED' : 'ACTIVE'] += 1; });
    return c;
  }, [trips]);

  const filtered = useMemo(() => {
    if (filter === 'ALL') return trips;
    if (filter === 'ACTIVE') return trips.filter(t => t.status !== 'ARCHIVED');
    return trips.filter(t => t.status === 'ARCHIVED');
  }, [trips, filter]);

  return (
    <div className="container">

      <div className="d-flex align-items-center justify-content-between my-3">
        <h1 className="h3 mb-0">Leader Dashboard</h1>
        <Link to="/trips/new" className="btn btn-primary">Create Trip</Link>
      </div>

      {/* Filter pills */}
      <div className="d-flex gap-2 mb-3">
        <button
          className={`btn btn-sm ${filter==='ACTIVE' ? 'btn-secondary' : 'btn-outline-secondary'}`}
          onClick={()=>setFilter('ACTIVE')}
        >
          Active ({counts.ACTIVE})
        </button>
        <button
          className={`btn btn-sm ${filter==='ARCHIVED' ? 'btn-secondary' : 'btn-outline-secondary'}`}
          onClick={()=>setFilter('ARCHIVED')}
        >
          Archived ({counts.ARCHIVED})
        </button>
        <button
          className={`btn btn-sm ${filter==='ALL' ? 'btn-secondary' : 'btn-outline-secondary'}`}
          onClick={()=>setFilter('ALL')}
        >
          All ({counts.ALL})
        </button>
      </div>

      {filtered.length === 0 ? (
        <div className="card p-3">
          <p className="text-muted mb-0">No trips in this view.</p>
        </div>
      ) : (
        <div className="row g-3">
        <AnimatePresence>
          {filtered.map(t => (
            <motion.div key={t.id} className="col-md-6" {...fadeSlide}>
              <TripCard t={t} memberCount={membersByTrip[t.id] || 0} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      
      )}
    </div>
  )
}
