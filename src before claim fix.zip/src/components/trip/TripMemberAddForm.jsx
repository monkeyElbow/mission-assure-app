// src/components/trip/TripMemberAddForm.jsx
import { useState } from 'react'
import { api } from '../../data/api'
import MinorFields from './MinorFields'

// simple US formatter: "(123) 456-7890"
function formatPhone(v) {
  const d = (v || '').replace(/\D/g, '').slice(0, 10)
  if (d.length <= 3) return d ? `(${d}` : ''
  if (d.length <= 6) return `(${d.slice(0,3)}) ${d.slice(3)}`
  return `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}`
}

export default function TripMemberAddForm({ tripId, onAdded }) {
  const [draft, setDraft] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    isMinor: false,
    guardianName: '',
    guardianEmail: '',
    guardianPhone: '',
  })
  const [saving, setSaving] = useState(false)

  // field updater for simple inputs + phone mask + switch
  function update(field) {
    return (e) => {
      const val =
        field === 'isMinor'
          ? e.target.checked
          : (field === 'phone' || field === 'guardianPhone')
          ? formatPhone(e.target.value)
          : e.target.value
      setDraft((d) => ({ ...d, [field]: val }))
    }
  }

  // patch helper so MinorFields can set multiple values at once
  function patch(obj) {
    setDraft((d) => ({ ...d, ...obj }))
  }

  async function handleAdd(e) {
    e.preventDefault()
    if (!draft.firstName || !draft.lastName) return alert('First and last name required.')
    if (draft.isMinor && !draft.guardianName) return alert('Guardian name required for a minor.')
    setSaving(true)
    try {
      await api.addMembers(tripId, [draft])
      setDraft({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        isMinor: false,
        guardianName: '',
        guardianEmail: '',
        guardianPhone: '',
      })
      onAdded?.()
    } finally {
      setSaving(false)
    }
  }


  return (
    <div className="card">
    <div className="card-header"><strong>Add Person</strong></div>
    <div className="card-body">
      <form onSubmit={handleAdd}>
        {/* Row 1: First / Last */}
        <div className="row g-2">
          <div className="col-12 col-md-6">
            <input
              className="form-control"
              placeholder="First name"
              value={draft.firstName}
              onChange={update('firstName')}
            />
          </div>
          <div className="col-12 col-md-6">
            <input
              className="form-control"
              placeholder="Last name"
              value={draft.lastName}
              onChange={update('lastName')}
            />
          </div>
        </div>

        {/* Row 2: Email / Phone */}
        <div className="row g-2 mt-2">
          <div className="col-12 col-md-7">
            <input
              type="email"
              className="form-control"
              placeholder="Email"
              value={draft.email}
              onChange={update('email')}
              autoComplete="email"
            />
          </div>
          <div className="col-12 col-md-5">
            <input
              className="form-control"
              placeholder="Phone"
              value={draft.phone}
              onChange={update('phone')}
              inputMode="tel"
              autoComplete="tel"
              maxLength={14} // (123) 456-7890
            />
          </div>
        </div>

        {/* Minor toggle */}
        <div className="row g-2 mt-3 mb-1 align-items-center">
          <div className="col">
            <div className="form-check form-switch ms-1">
              <input
                className="form-check-input"
                type="checkbox"
                id="member-isMinor"
                checked={draft.isMinor}
                onChange={update('isMinor')}
                aria-expanded={draft.isMinor}
                aria-controls="minor-fields"
              />
              <label className="form-check-label" htmlFor="member-isMinor">
                Minor (17 or younger)
              </label>
            </div>
          </div>
          <div className="col-auto ms-auto">
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? 'Adding…' : 'Add Person'}
            </button>
          </div>
        </div>

        {/* Animated guardian fields */}
        <MinorFields open={draft.isMinor} values={draft} onChange={patch} />
      </form>
    </div>
  </div>)
}

