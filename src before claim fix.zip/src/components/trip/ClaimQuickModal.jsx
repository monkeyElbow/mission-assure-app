import { useState, useMemo } from 'react'
import Modal from '../shared/Modal'
import { createClaim } from '/src/core/claims'

export default function ClaimQuickModal({ open, onClose, trip, members = [] }) {
  const [memberId, setMemberId] = useState('')
  const [reason, setReason] = useState('')

  const selected = useMemo(
    () => members.find(m => m.id === memberId) || null,
    [members, memberId]
  )

  function handleSubmit() {
    if (!selected) { alert('Select a traveler.'); return; }
    if (!reason.trim()) { alert('Add a brief reason.'); return; }

    // Minimal incident snapshot; Claims page lets admins triage further
    const today = new Date().toISOString().slice(0,10)

    createClaim({
      tripId: trip.id,
      tripTitle: trip.title,
      // claimant (member involved)
      memberName: `${selected.firstName || ''} ${selected.lastName || ''}`.trim() || selected.email,
      memberEmail: selected.email || '',
      // reporter (the person filing; for now we mark as Leader)
      reporterName: 'Leader',
      reporterEmail: '',
      role: 'LEADER',
      // incident snapshot
      incidentType: 'CLAIM',
      incidentDate: today,
      incidentLocation: trip.region || '',
      description: reason
    })

    // reset + close
    setMemberId('')
    setReason('')
    onClose?.('submitted')
  }

  return (
    <Modal
      open={open}
      title="File a Claim"
      onClose={()=> onClose?.()}
      footer={
        <>
          <button className="btn btn-outline-secondary" onClick={()=> onClose?.()}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSubmit}>Submit Claim</button>
        </>
      }
    >
      <div className="mb-3">
        <label className="form-label">Who is this claim for?</label>
        <select
          className="form-select"
          value={memberId}
          onChange={e => setMemberId(e.target.value)}
        >
          <option value="">— Select traveler —</option>
          {members.map(m => (
            <option key={m.id} value={m.id}>
              {(m.firstName || m.lastName) ? `${m.firstName || ''} ${m.lastName || ''}`.trim() : m.email}
            </option>
          ))}
        </select>
      </div>

      <div className="mb-2">
        <label className="form-label">Reason for claim</label>
        <textarea
          className="form-control"
          rows={4}
          placeholder="Briefly describe what happened…"
          value={reason}
          onChange={e => setReason(e.target.value)}
        />
      </div>

      <p className="small text-muted mt-2">
        Please email any supporting documents to <a href="mailto:missionassure@agfinancial.org">missionassure@agfinancial.org</a>.
      </p>
    </Modal>
  )
}
